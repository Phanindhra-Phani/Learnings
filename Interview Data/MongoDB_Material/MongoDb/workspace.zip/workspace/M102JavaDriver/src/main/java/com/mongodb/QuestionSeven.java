package com.mongodb;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class QuestionSeven {

	public static void main(String[] args) {
		Set<Integer> listOFImagesInAlbums = new HashSet<Integer>();
		Set<Integer> orphanImages = new HashSet<Integer>();
		MongoClient client = new MongoClient();
		MongoDatabase database = client.getDatabase("questionSeven");

		// All the Albums
		MongoCollection<Document> albums = database.getCollection("albums");

		MongoCursor<Document> albumCursor = albums.find().iterator();
		int count = 0;
		while (albumCursor.hasNext()) {
			count++;
			Document type = (Document) albumCursor.next();
			List<Integer> obj = (ArrayList<Integer>) type.get("images");
			listOFImagesInAlbums.addAll(obj);

		}

		System.out.println(count + "  " + listOFImagesInAlbums.size());

		// All the images
		MongoCollection<Document> images = database.getCollection("images");

		MongoCursor<Document> imagesCursor = images.find().iterator();
		int countOfImages = 0;
		while (imagesCursor.hasNext()) {
			countOfImages++;
			Document image = (Document) imagesCursor.next();
			Integer obj = (Integer) image.get("_id");

			if (!listOFImagesInAlbums.contains(obj)) {
				orphanImages.add(obj);
			}

		}
		
		
		System.out.println("Orphan Images" + orphanImages.size());
		
		images.deleteMany(new Document().append("_id", new Document().append("$in", orphanImages)));
		

		

	}

}
