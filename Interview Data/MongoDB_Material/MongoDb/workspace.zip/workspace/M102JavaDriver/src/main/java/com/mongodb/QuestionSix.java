package com.mongodb;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class QuestionSix {

	public static void main(String[] args) {

		MongoClient client = new MongoClient();
		MongoDatabase database = client.getDatabase("questionFive");

		MongoCollection<Document> collection = database.getCollection("stuff");

		collection.drop();

		for (int a = 4950; a < 5050; a++) {

			for (int b = 4950; b < 5050; b++) {

				for (int c = 6000; c < 6045; c++) {

					Document document = new Document().append("a", a)
							.append("b", b).append("c", c*7);

					System.out.println( a + "  "  + b + "  " + c );
					collection.insertOne(document);
					
				}

			}
		}

	}

}
