package com.mongodb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class Find {

	public static void main(String[] args) {

		MongoClient client = new MongoClient();
		MongoDatabase database = client.getDatabase("course");

		MongoCollection<Document> collection = database
				.getCollection("courseCollection");

		collection.drop();

		Document document = new Document().append("name", "Pranith")
				.append("age", 30).append("profession", "Programmer");

		Document document1 = new Document().append("name", "Krishna")
				.append("age", 27).append("profession", "Programmer");

		Document document2 = new Document().append("name", "rao")
				.append("age", 25).append("profession", "Programmer");

		collection.insertMany(Arrays.asList(document, document1, document2));

		// To get the first Document
		Document firstDoc = collection.find().first();
		System.out.println(firstDoc.get("_id"));

		// To get the multiple Document, if the size of the documents is less
		List<Document> list = collection.find().into(new ArrayList<Document>());

		for (Document docs : list) {
			System.out.println(docs.get("_id"));
		}

		// To get the multiple Document, if the size of the documents is very
		// more
		MongoCursor<Document> cursor = collection.find().iterator();

		try {
			// using try finally, becuae we have to close the cursor resource in
			// all the cases
			while (cursor.hasNext()) {
				Document docs = cursor.next();
				System.out.println(docs.get("_id"));

			}

		} finally {
			cursor.close();
		}

		// to fetch the count of the collection
		Long count = collection.count();
		System.out.println(" count  " + count);

	}

}
