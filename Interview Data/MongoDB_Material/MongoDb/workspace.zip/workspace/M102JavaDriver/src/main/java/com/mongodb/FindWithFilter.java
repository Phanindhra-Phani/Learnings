package com.mongodb;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;
import com.mongodb.operation.OrderBy;

public class FindWithFilter {

	public static void main(String[] args) {

		MongoClient client = new MongoClient();
		MongoDatabase database = client.getDatabase("course");

		MongoCollection<Document> collection = database
				.getCollection("courseCollection");

		collection.drop();

		Document document = new Document().append("name", "Pranith")
				.append("age", 30).append("profession", "Programmer");

		Document document1 = new Document().append("name", "Krishna")
				.append("age", 27).append("profession", "Programmer");

		Document document2 = new Document().append("name", "rao")
				.append("age", 25).append("profession", "Programmer");

		collection.insertMany(Arrays.asList(document, document1, document2));

//		Bson filter = new Document()
//								.append("age", 25)
//								.append("x", new Document().append("$gt", 55).append("$lt", 99));
		
		Bson filter = Filters.and(Filters.eq("age", 25), Filters.gt("x", 55) , Filters.lt("x", 99));
		
		Bson projection1 = Projections.exclude("x","_id");
		Bson projection2 = Projections.include("y","j");
		Bson projection3 = Projections.fields(Projections.include("y","j"),Projections.excludeId()) ;
		
		Bson sorting1 = Sorts.ascending("x","z");
		Bson sorting2 = Sorts.descending("y");
		Bson sorting = Sorts.orderBy(sorting1,sorting2);
		MongoCursor<Document> cursor = collection.find(filter)
													.projection(projection1)
																.sort(sorting)
																.skip(20)
																.limit(50)
																.iterator();
		// To get the first Document
		Document firstDoc = collection.find(filter).first();
		System.out.println(firstDoc.get("_id"));

		// To get the multiple Document, if the size of the documents is less
		List<Document> list = collection.find(filter).into(new ArrayList<Document>());

		for (Document docs : list) {
			System.out.println(docs.get("_id"));
		}

		// To get the multiple Document, if the size of the documents is very
		// more
		//MongoCursor<Document> cursor = collection.find(filter).projection(projection1).sort(sorting).iterator();

		try {
			// using try finally, becuae we have to close the cursor resource in
			// all the cases
			while (cursor.hasNext()) {
				Document docs = cursor.next();
				System.out.println(docs.get("_id"));

			}

		} finally {
			cursor.close();
		}

		
		collection.replaceOne(new Document().append("x", 5), new Document().append("_id", 5).append("x", 25).append("y", 15) );
		
		//collection.replaceOne(new Document().append("x", 5), new Document().append("$set", new Document().append("x", 25))
		
		// to fetch the count of the collection
		Long count = collection.count(filter);
		System.out.println(" count  " + count);

	}

}
