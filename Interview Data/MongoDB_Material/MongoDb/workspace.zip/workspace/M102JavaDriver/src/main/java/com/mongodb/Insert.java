package com.mongodb;

import java.util.Arrays;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Insert {

	public static void main(String[] args) {

		MongoClient client = new MongoClient();
		MongoDatabase database = client.getDatabase("course");

		MongoCollection<Document> collection = database
				.getCollection("courseCollection");

		collection.drop();

		Document document = new Document().append("name", "Pranith")
				.append("age", 30).append("profession", "Programmer");

		collection.insertOne(document);

		Document document1 = new Document().append("name", "Krishna")
				.append("age", 27).append("profession", "Programmer");

		Document document2 = new Document().append("name", "rao")
				.append("age", 25).append("profession", "Programmer");

		collection.insertMany(Arrays.asList(document1, document2));
	}

}
