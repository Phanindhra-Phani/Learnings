package com.mongodb;

import java.util.Arrays;
import java.util.Date;

import org.bson.BsonDocument;
import org.bson.Document;
import org.bson.json.JsonWriter;
import org.bson.types.ObjectId;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Main {

	public static void main(String[] args) {

		//MongoClient client = new MongoClient("localhost",27017);
		
//		MongoClient client = new MongoClient(Arrays.asList(new ServerAddress("localhost",27017)));

		MongoClientOptions options = MongoClientOptions.builder().connectionsPerHost(1000).build();
		MongoClient client = new MongoClient(new ServerAddress(), options);
		
		MongoDatabase database = client.getDatabase("test");
		database.withReadPreference(ReadPreference.secondary());
		
		MongoCollection<Document> collection = database.getCollection("test");
		
		MongoCollection<BsonDocument> collection1 = database.getCollection("test",BsonDocument.class);
		
		
		Document document = new Document();
		document.append("key", "Hello World")
				.append("int", 1)
				.append("l", 1l)
				.append("double", 1.1)
				.append("b", false)
				.append("date", new Date())
				.append("objectId", new ObjectId())
				.append("null", null)
				.append("embededDOC", new Document("x","doc"))
				.append("arrays", Arrays.asList(1,2,3))
				;
		
		String value = (String)document.get("key");
		
		
		
	}

}
