package com.mongodb;

import java.util.Arrays;
import java.util.List;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class Aggregation {

	public static void main(String[] args) {

		MongoClient client = new MongoClient();
		MongoDatabase database = client.getDatabase("m101");

		MongoCollection<Document> collection = database.getCollection("zips");

//		Document document = new Document().append(
//				"$group",
//				new Document().append("_id", "$state").append("PopulatonCount",
//						new Document().append("$sum", "$pop")));
		
		Document document1 = Document.parse("{$group:{_id :\"$state\",count:{$sum:\"$pop\"}}}");

		List<Document> pipeline = Arrays.asList(document1);

		MongoCursor<Document> cursor = collection.aggregate(pipeline)
				.iterator();
		try {
			while (cursor.hasNext()) {
				Document docs = cursor.next();
				System.out.println(docs.get("_id"));

			}

		} finally {
			cursor.close();
		}

		client.close();
	}

}
