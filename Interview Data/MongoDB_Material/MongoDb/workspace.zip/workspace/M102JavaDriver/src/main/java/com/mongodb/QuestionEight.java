package com.mongodb;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class QuestionEight {

	public static void main(String[] args) {

		MongoClient client = new MongoClient();
		MongoDatabase database = client.getDatabase("questionEight");

		MongoCollection<Document> animals = database.getCollection("animals");
		animals.drop();
		Document animal = new Document("animal", "monkey");

		animals.insertOne(animal);
		animal.remove("animal");
		animal.append("animal", "cat");
		System.out.println(animal.getObjectId("_id"));
		System.out.println(animal.getString("animal"));
		animals.insertOne(animal);
		animal.remove("animal");
		animal.append("animal", "lion");
		animals.insertOne(animal);

	}

}
