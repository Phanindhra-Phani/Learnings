package com.mongodb.MavenSample;

import spark.Request;
import spark.Response;
import spark.Route;
import spark.Spark;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Spark.get(new Route("/") {

			@Override
			public Object handle(Request arg0, Response arg1) {
				// TODO Auto-generated method stub
				return "Hi this home page";
			}
		});

		Spark.get(new Route("/test") {

			@Override
			public Object handle(Request arg0, Response arg1) {
				// TODO Auto-generated method stub
				return "Hi this is Test page";
			}
		});

		Spark.get(new Route("/echo/:thing") {

			@Override
			public Object handle(Request request, Response response) {
				// TODO Auto-generated method stub
				return "Hi this is " + request.params("thing");
			}
		});
	}
}
