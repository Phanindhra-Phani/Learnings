package com.mongodb.MavenSample;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import freemarker.template.Configuration;
import freemarker.template.Template;
import spark.Request;
import spark.Response;
import spark.Route;
import spark.Spark;

/**
 * Hello world!
 *
 */
public class FreeMarkerSample {
	public static void main(String[] args) {

		StringWriter stringWriter = new StringWriter();
		
		//Step 1
		Configuration configuration = new Configuration();

		//Step 2
		configuration.setClassForTemplateLoading(FreeMarkerSample.class, "/");
		try {
			
			//Step 3
			Template helloTemplate = configuration.getTemplate("hello.ftl");

			//Step 4
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("name", "Krishna Pranith");

			//Step 5
			helloTemplate.process(map, stringWriter);
			System.out.println(stringWriter);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
