package com.mongodb.MavenSample;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import spark.Request;
import spark.Response;
import spark.Route;
import spark.Spark;
import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		final Configuration configuration = new Configuration();
		configuration.setClassForTemplateLoading(App.class, "/");
		Spark.get(new Route("/") {

			@Override
			public Object handle(Request arg0, Response arg1) {
				StringWriter out = new StringWriter();
				try {
					Template template = configuration.getTemplate("hello.ftl");

					Map<String, Object> map = new HashMap<String, Object>();
					map.put("name", "James bond");

					template.process(map, out);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return out.toString();
			}
		});
	}
}
