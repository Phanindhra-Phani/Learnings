package com.cat.azcrms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzCrmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AzCrmsApplication.class, args);
	}

}
